package edu.udayton.personalplaylist;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    private Button btnUkelele, btnDrums, btnRaone;

    private MediaPlayer mpUkelele, mpDrums, mpRaone;

    private int playing;

    private static final int NOT_PLAYING = 0, PLAYING = 1;

    private static final String UKELELE_PLAYING = "Pause Sahoo Song",
            UKELELE_PAUSED = "Play Sahoo Song",
            DRUMS_PLAYING = "Pause Bahubali Song",
            DRUMS_PAUSED = "Play Bahubali Song",
            RAONE_PLAYING = "Pause Raone Song",
            RAONE_PAUSED = "Play Raone Song";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUkelele = (Button) findViewById(R.id.btnUkelele);
        btnDrums = (Button) findViewById(R.id.btnDrums);
        btnRaone = (Button) findViewById(R.id.btnRaone);

        btnUkelele.setOnClickListener(btnUkeleleListener);
        btnDrums.setOnClickListener(btnDrumsListener);
        btnRaone.setOnClickListener(btnRaoneListener);

        mpUkelele = new MediaPlayer();
        mpUkelele = MediaPlayer.create(this, R.raw.saiyaan);

        mpDrums = new MediaPlayer();
        mpDrums = MediaPlayer.create(this, R.raw.saahore);

        mpRaone = new MediaPlayer();
        mpRaone = MediaPlayer.create(this, R.raw.raone);

        playing = NOT_PLAYING;


    }

    Button.OnClickListener btnUkeleleListener = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (playing) {
                case NOT_PLAYING:
                    mpUkelele.start();
                    playing = PLAYING;

                    btnUkelele.setText(UKELELE_PLAYING);

                    btnDrums.setVisibility(View.INVISIBLE);

                    break;
                case PLAYING:
                    mpUkelele.pause();
                    playing = NOT_PLAYING;

                    btnUkelele.setText(UKELELE_PAUSED);

                    btnDrums.setVisibility(View.VISIBLE);
                    break;
            }

        }
    };
    Button.OnClickListener btnDrumsListener = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (playing) {
                case NOT_PLAYING:
                    mpDrums.start();
                    playing = PLAYING;

                    btnDrums.setText(DRUMS_PLAYING);

                    btnUkelele.setVisibility(View.INVISIBLE);

                    break;
                case PLAYING:
                    mpDrums.pause();
                    playing = NOT_PLAYING;

                    btnDrums.setText(DRUMS_PAUSED);

                    btnUkelele.setVisibility(View.VISIBLE);
                    break;
            }
        }
    };
    Button.OnClickListener btnRaoneListener = new Button.OnClickListener() {

        @Override
        public void onClick(View v) {
            switch (playing) {
                case NOT_PLAYING:
                    mpRaone.start();
                    playing = PLAYING;

                    btnRaone.setText(RAONE_PLAYING);

                    btnDrums.setVisibility(View.INVISIBLE);
                    btnUkelele.setVisibility(View.INVISIBLE);

                    break;
                case PLAYING:
                    mpUkelele.pause();
                    playing = NOT_PLAYING;

                    btnRaone.setText(RAONE_PAUSED);

                    btnDrums.setVisibility(View.VISIBLE);
                    btnUkelele.setVisibility(View.VISIBLE);
                    break;
            }
        }
    };
    }


