package edu.udayton.latestmusicsceneapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = findViewById(R.id.button1);
        Button b2 = findViewById(R.id.button2);
        View.OnClickListener b1Listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent drawnIntent;
                drawnIntent = new Intent(MainActivity.this, Drawn.class);
                startActivity(drawnIntent);
            }
        };
        View.OnClickListener b2Listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent drawnIntent;
                drawnIntent = new Intent(MainActivity.this, Shawn.class);
                startActivity(drawnIntent);
            }
        };
        b1.setOnClickListener(b1Listener);
        b2.setOnClickListener(b2Listener);
    }
}
