package edu.udayton.currencyconversion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends Activity {

    private final double CONVERSION_RATE1 = 0.89; //currency in euros
    private final double CONVERSION_RATE2 = 19.20; //currency in euros
    private final double CONVERSION_RATE3 = 1.33; //currency in euros

    private final int USD_LIMIT = 1000;
    private final int EURO_LIMIT = 1000;
    private double amountEntered, convertedAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btnConvert = (Button)findViewById(R.id.btnConvert);

        View.OnClickListener btnConvertListener = new View.OnClickListener()
        {
            final EditText txtAmount = (EditText)findViewById(R.id.txtAmount);
            final RadioButton radUsdToEuros = (RadioButton)findViewById(R.id.radUsdToEuros);
            final RadioButton radUsdToMexicanPesos = (RadioButton)findViewById(R.id.radUsdToMexicanPesos);
            final RadioButton radUsdToCanadianDollars = (RadioButton)findViewById(R.id.radUsdToCanadianDollars);

            final TextView txtResult = (TextView)findViewById(R.id.txtResult);

            final DecimalFormat formatter = new DecimalFormat("#.##");

            @Override
            public void onClick(View v) {
                String InputString = txtAmount.getText().toString();
                String OutputString = "Invalid Data Entered";
                try {
                    amountEntered = Double.parseDouble(InputString);

                    if (radUsdToEuros.isChecked())
                    {
                        if (amountEntered <= USD_LIMIT )
                        {
                            convertedAmount = amountEntered*CONVERSION_RATE1;
                            OutputString = formatter.format(convertedAmount)+"Euros";
                        }

                    }
                    else if (radUsdToMexicanPesos.isChecked())
                        {
                            if (amountEntered <= USD_LIMIT )
                            {
                                convertedAmount = amountEntered*CONVERSION_RATE2;

                                OutputString = formatter.format(convertedAmount)+"MexicanPesos";
                            }
                        }
                    else
                    {
                        if (radUsdToCanadianDollars.isChecked())
                        {
                            if (amountEntered <= USD_LIMIT )
                            {
                                convertedAmount = amountEntered*CONVERSION_RATE3;

                                OutputString = formatter.format(convertedAmount)+"CanadianDollars";
                            }
                        }
                    }

                }catch (Exception e)
                {
                    Toast myToast = Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG);
                    myToast.show();
                }

            txtResult.setText(OutputString);
            }
        };
        btnConvert.setOnClickListener(btnConvertListener);
    }
}
