package edu.udayton.techgadgets;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Picture extends AppCompatActivity {

    public static final String ID_KEY="RES_ID", LBL_KEY="LABEL",BTN = "BTN_LABEL", URL = "URL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);

        // get the extras from the Intent
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        if(extras!=null) // make sure there are extras
        {
            // get the String extra with key=LBL_KEY
            String res_label = extras.getString(LBL_KEY);

            // display the labelString in the titleTextView
            final TextView pictureTitle = (TextView) findViewById(R.id.titleTextView);
            pictureTitle.setText(res_label);

            String btnLbl = extras.getString(BTN);
            final Button btnLabel = (Button) findViewById(R.id.button);
            btnLabel.setText(btnLbl);

            // get the String extra with key=ID_KEY
            String image_id = extras.getString(ID_KEY);


            // convert the resource ID from String to integer
            int imageID = Integer.parseInt(image_id);


            final String url = extras.getString(URL);
            final Button btnSite = (Button) findViewById(R.id.button);
            btnSite.setTransformationMethod(null);
            View.OnClickListener buttonListener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent1);
                }
            };
            btnSite.setOnClickListener(buttonListener);


            /*
                in the pictureImageView
                    1. display the image with the imageID resource id
                    2. change the content description to the res_label String
             */

            final ImageView picture = (ImageView) findViewById(R.id.pictureImageView);
            picture.setImageResource(imageID);
            picture.setContentDescription(res_label);
            picture.setOnClickListener(buttonListener);
        }
    }// end onCreate method
}// end Picture class
