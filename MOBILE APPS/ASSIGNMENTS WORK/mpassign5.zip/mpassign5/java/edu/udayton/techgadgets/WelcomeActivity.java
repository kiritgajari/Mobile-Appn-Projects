package edu.udayton.techgadgets;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        //get constants reference to the opening button
        final Button openBtn= (Button)findViewById(R.id.buttonOpen);

        View.OnClickListener btnListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create the intent to start the Mainactivity
                Intent intent = new Intent(WelcomeActivity.this,MainActivity.class);

                //launch MainActivity via intent
                startActivity(intent);

            }
        };
        //set the btnListener as openbtn Listeners

        openBtn.setOnClickListener(btnListener);
    }//end of oncreate method
}//end of  Welcome Activity
