package edu.udayton.splitthebill;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Bill1 extends AppCompatActivity {


    private int numberOfPeople;
    private double totalCost;
    private String groupChoice;
    private float res_amt;
    private double tip;
    private double tip_only;
    private String m;
    private String Output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bill1);

        //setting the cost button reference

        final Button btnCost = (Button)findViewById(R.id.btnCost);

        //validate the btnCost reference

        assert btnCost !=null;
        View.OnClickListener costListener = new View.OnClickListener() {


            final EditText bill = (EditText)findViewById(R.id.txtBill);
            final EditText people = (EditText)findViewById(R.id.txtPeople);
            final Spinner group = (Spinner)findViewById(R.id.txtGroup);
            final TextView result = (TextView)findViewById(R.id.txtResult);
            @Override
            public void onClick(View v) {

                //get the bill amount (user input)

                Editable Input = people.getText();
                String InputStr = Input.toString();

                Editable Input1 = bill.getText();
                String InputStr1 = Input1.toString();



                //use exception handler in case of no input

                try{
                    //convert input string (InputStr) to integer

                    numberOfPeople=Integer.parseInt(InputStr);
                    res_amt=Float.parseFloat(InputStr1);

                    //calculate the total cost of the tickets
                    totalCost = res_amt / numberOfPeople;

                    //get the chosen group from the spinner
                    groupChoice=group.getSelectedItem().toString();
                    if(groupChoice.contains("Excellent Service")){
                        tip= totalCost + (totalCost*0.20);
                        tip_only = totalCost*0.20;
                        m = "One of the best meals ever! \n" +
                                "I will recommend this place to everyone I know!";
                    }else if(groupChoice.contains("Average Service"))
                    {
                        tip= totalCost + (totalCost*0.15);
                        tip_only = totalCost*0.15;
                        m = "Everything was OK";

                    }else if(groupChoice.contains("Poor Service")){
                        tip= totalCost + (totalCost*0.05);
                        tip_only = totalCost*0.05;
                        m = "Awful!  The worst!  I can't wait to" +
                                "give negative reviews on Yelp!";
                    }

                    //set up the currency formatter for the ticket cost output

                    DecimalFormat currency =new DecimalFormat("$###,###.##");


                    //output the total ticket cost and the chosen group
                    Output ="Cost per Head without Tip:"+currency.format(totalCost)+
                    "\nCost per head :"+currency.format(tip)+"\nTip per person:"
                            +currency.format(tip_only)+"\n"+m;
                            //currency.format(totalCost);

                    result.setText(Output);

                }catch (Exception e){

                    Log.e(e.getMessage(),e.toString());

                }




            }//end of onClick handler
        };

        //set the btnCost listener

        btnCost.setOnClickListener(costListener);

    }//enf of onCreate method
}//end of MainActivity class
