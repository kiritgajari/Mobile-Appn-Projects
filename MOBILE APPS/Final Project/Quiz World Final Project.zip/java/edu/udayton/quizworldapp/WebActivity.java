package edu.udayton.quizworldapp;

import android.app.ListActivity;
import android.content.Intent;
import android.graphics.Picture;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class WebActivity extends ListActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // convert the string-array 'gadgets' to a list

        List<String> Gadgets =
                Arrays.asList(getResources().getStringArray(R.array.gadgets));

        // inflate the GUI with the gadgets list

        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_web,
                R.id.you, Gadgets));

    }// end onCreate method


    protected void onListItemClick(ListView I, View v, int position, long id)
    {
        Intent intent ;


        switch (position)
        {

            case 0:// Night Guide (web page, image)
                intent = new Intent(WebActivity.this, PictureActivity.class);

                // add label text and resource id to the intent as String extras

                intent.putExtra(PictureActivity.LBL_KEY, getResources().getString(R.string.txtNight));
                intent.putExtra(PictureActivity.ID_KEY, Integer.toString(R.drawable.img11));
                intent.putExtra(PictureActivity.BTN, getResources().getString(R.string.btnNight));
                intent.putExtra(PictureActivity.URL,getResources().getString(R.string.nightURL));
                break;

            case 1:// Skywire Tv (web page, image)
                intent = new Intent(WebActivity.this, PictureActivity.class);

                // add label text and resource id to the intent as String extras

                intent.putExtra(PictureActivity.LBL_KEY, getResources().getString(R.string.txtskywire));
                intent.putExtra(PictureActivity.ID_KEY, Integer.toString(R.drawable.img22));
                intent.putExtra(PictureActivity.BTN, getResources().getString(R.string.btnSkywire));
                intent.putExtra(PictureActivity.URL,getResources().getString(R.string.skywireURL));
                break;
            case 2://Starscope Monocular (web page, image)
                intent = new Intent(WebActivity.this, PictureActivity.class);

                // add label text and resource id to the intent as String extras

                intent.putExtra(PictureActivity.LBL_KEY, getResources().getString(R.string.txtStars));
                intent.putExtra(PictureActivity.ID_KEY, Integer.toString(R.drawable.img33));
                intent.putExtra(PictureActivity.BTN, getResources().getString(R.string.btnStarscope));
                intent.putExtra(PictureActivity.URL,getResources().getString(R.string.starscopeURL));
                break;
            case 3:// Tc 1200 Flashlight (web page, image)
                intent = new Intent(WebActivity.this, PictureActivity.class);

                // add label text and resource id to the intent as String extras

                intent.putExtra(PictureActivity.LBL_KEY, getResources().getString(R.string.txtTC1200));
                intent.putExtra(PictureActivity.ID_KEY, Integer.toString(R.drawable.img44));
                intent.putExtra(PictureActivity.BTN, getResources().getString(R.string.btnTC));
                intent.putExtra(PictureActivity.URL,getResources().getString(R.string.tcURL));
                break;
            case 4: //CircaCharge (web page, image)
                intent = new Intent(WebActivity.this, PictureActivity.class);

                // add label text and resource id to the intent as String extras

                intent.putExtra(PictureActivity.LBL_KEY, getResources().getString(R.string.txtCircaCharge));
                intent.putExtra(PictureActivity.ID_KEY, Integer.toString(R.drawable.img55));
                intent.putExtra(PictureActivity.BTN, getResources().getString(R.string.btnCircaCharge));
                intent.putExtra(PictureActivity.URL,getResources().getString(R.string.circaURL));
                break;

            default:
                Toast toast = Toast.makeText(WebActivity.this,
                        "Invalid choice Made", Toast.LENGTH_LONG);
                toast.show();
                intent=null;
        }// end switch

        //start the activity via the intent(if there is one)
        if(intent!=null) {
            startActivity(intent);
        }
    }// end onListItemClick


}// end MainActivity class
