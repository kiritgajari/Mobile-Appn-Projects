package edu.udayton.quizworldapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView resultCount = findViewById(R.id.resultCount);
        TextView resultFinal = findViewById(R.id.resultFinal);
        int score=getIntent().getIntExtra("RIGHT_ANSWER_COUNT",0);

        SharedPreferences settings = getSharedPreferences("QuizWorldApp", Context.MODE_PRIVATE);

        int finalScore = settings.getInt("finalScore",0);
        finalScore+=score;
        resultCount.setText(score + "/5");
        resultFinal.setText("Final Score :" + score);

        //update the totalScore
        SharedPreferences.Editor editor =settings.edit();
        editor.putInt("finalScore", finalScore);
        editor.apply();
        final Button b = (Button)findViewById(R.id.button2);
                //add event handler for Button b

        View.OnClickListener bListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an Intent for the Bill screen

                Intent i =new Intent(ResultActivity.this,WebActivity.class);

                // start a new activity with the intent i
                startActivity(i);
            }
        };
        b.setOnClickListener(bListener);
        final Button c = (Button)findViewById(R.id.button3);
        View.OnClickListener cListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an Intent for the Bill screen

                Intent i =new Intent(ResultActivity.this, WelcomeActivity.class);

                // start a new activity with the intent i
                startActivity(i);
            }
        };

        //set the split button b's event handler


        c.setOnClickListener(cListener);

    }



    }



