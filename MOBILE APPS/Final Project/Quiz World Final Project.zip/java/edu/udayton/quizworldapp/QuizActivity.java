package edu.udayton.quizworldapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class QuizActivity extends AppCompatActivity {

    private TextView numberCount;
    private TextView questions;
    private Button optionBtn1;
    private Button optionBtn2;
    private Button optionBtn3;
    private Button optionBtn4;
    private String correctAnswer;
    private int correctAnswerCount=0;
    private int qCount=1;
    private final int Q_COUNT=5;
    ArrayList<ArrayList<String>> qArray =new ArrayList<>();
    String qData [][]=
            {
            //{"Countryname","RightAnswer","opt1","opt2","opt3};
            {"Afghanistan","Kabul","Bankok","Dili","Stockholm"},
            {"Algeria","Algiers","Tirana ","Albania","Akrotiri"},
            {"Bahrain","Manama","Dhaka","Barbados","Bridgetown"},
            {"Cameroon","Yaounde","Phnom Penh","Praia","Cape Verde "},
            {"Dominica","Roseau","Santo Domingo","Djibouti ","Manila"},
            {"Ecuador","Quito","Bankok","Dili","Malabo"},
            {"FaroeIslands","Torshavn","Stanley","Helsinki","Paris"},
            {"Gabon","Libreville","Banjul","T'bilisi","Berlin"},
            {"Haiti","Port-au-Prince","Vatican City","Tegucigalpa","Budapest"},
            {"Iceland","Reykjavik","Jakarta","Tehran","Baghdad"},
            {"Jamaica","Kingston","Tokyo","Saint Helier","Amman"},
            {"Laos","Vientiane ","Riga","Beirut","Maseru"},
            {"Macedonia","Skopje ","Antananarivo","Lilongwe","Male"},
            {"Namibia","Windhoek","Kathmandu","Noumea","Wellington"},
            {"Oman","Muscat ","Oslo","Alofi","Kingston"}
    };




    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        numberCount = findViewById(R.id.numberCount);
        questions = findViewById(R.id.questions);
        optionBtn1 = findViewById(R.id.optionBtn1);
        optionBtn2 = findViewById(R.id.optionBtn2);
        optionBtn3 = findViewById(R.id.optionBtn3);
        optionBtn4 = findViewById(R.id.optionBtn4);

        //Create Quiz Array from Quiz Data
        for (int i=0;i<qData.length;i++){
            ArrayList<String> randomArray=new ArrayList<>();
            randomArray.add(qData[i][0]);
            randomArray.add(qData[i][1]);
            randomArray.add(qData[i][2]);
            randomArray.add(qData[i][3]);
            randomArray.add(qData[i][4]);

            // add tmpArray to QuiArray
            qArray.add(randomArray);
        }
        showNextQuiz();
    }
    public  void showNextQuiz(){
        numberCount.setText("QUESTION " + qCount);
        //Generating a random number between 0 and quizArray's length -1
        Random random =new Random();
        int randomNum=random.nextInt(qArray.size());
        ArrayList<String> Quiz = qArray.get(randomNum);
        questions.setText("Capital of " + Quiz.get(0) + "?");
        correctAnswer=Quiz.get(1);
        Quiz.remove(0);
        Collections.shuffle(Quiz);
        optionBtn1.setText(Quiz.get(0));
        optionBtn2.setText(Quiz.get(1));
        optionBtn3.setText(Quiz.get(2));
        optionBtn4.setText(Quiz.get(3));

        qArray.remove(randomNum);
    }

    public void checkAnswer(View view){
        Button ansButton= findViewById(view.getId());
        String btntxt= ansButton.getText().toString();
        String alertTitle;
        if(btntxt.equals(correctAnswer)){
            alertTitle="RIGHT ANSWER :-)";
            correctAnswerCount++;
        }
        else{
            alertTitle="WRONG ANSWER :-(";
        }
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle(alertTitle);
        builder.setMessage("CORRECT ANSWER: " + correctAnswer);
        builder.setPositiveButton("--NEXT-->", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (qCount == Q_COUNT){
                    //show result
                    Intent intent=new Intent(getApplicationContext(),ResultActivity.class);
                    intent.putExtra("RIGHT_ANSWER_COUNT",correctAnswerCount);
                    startActivity(intent);
                }
                else {
                    qCount++;
                    showNextQuiz();
                }

            }
        });
        builder.setCancelable(false);
        builder.show();


    }

}


