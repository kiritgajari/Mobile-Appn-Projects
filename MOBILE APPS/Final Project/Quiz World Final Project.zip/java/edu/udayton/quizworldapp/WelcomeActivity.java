package edu.udayton.quizworldapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WelcomeActivity extends AppCompatActivity {

    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        final Button b = (Button)findViewById(R.id.button1);


        //add event handler for Button b

        View.OnClickListener bListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create an Intent for the Bill screen

                Intent i =new Intent(WelcomeActivity.this,QuizActivity.class);

                // start a new activity with the intent i
                startActivity(i);
            }
        };

        //set the split button b's event handler

        b.setOnClickListener(bListener);

    }
}
